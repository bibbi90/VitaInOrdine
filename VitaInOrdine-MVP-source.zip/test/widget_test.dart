import 'package:flutter_test/flutter_test.dart';
import 'package:vita_in_ordine/main.dart';

void main() {
  test('Entry serializes and restores a due date', () {
    final due = DateTime(2026, 12, 1);
    final entry = Entry(id: '1', title: 'Luce', type: 'Bol­letta', due: due);
    final restored = Entry.fromJson(entry.toJson());
    expect(restored.title, 'Luce');
    expect(restored.due, due);
  });
}
