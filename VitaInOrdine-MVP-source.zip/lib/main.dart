import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';

final notifications = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  await notifications.initialize(const InitializationSettings(android: android));
  runApp(const VitaInOrdineApp());
}

class VitaInOrdineApp extends StatelessWidget {
  const VitaInOrdineApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VitaInOrdine',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF315C79)),
      scaffoldBackgroundColor: const Color(0xFFF5F7F9),
    ),
    home: const HomePage(),
  );
}

class Entry {
  Entry({required this.id, required this.title, required this.type,
    required this.due, this.amount = '', this.person = 'Famiglia',
    this.status = 'Da fare', this.filePath = '', this.notes = ''});
  final String id, title, type, amount, person, status, filePath, notes;
  final DateTime due;
  Map<String, dynamic> toJson() => {
    'id':id,'title':title,'type':type,'due':due.toIso8601String(),
    'amount':amount,'person':person,'status':status,'filePath':filePath,'notes':notes};
  factory Entry.fromJson(Map<String,dynamic> j) => Entry(
    id:j['id'], title:j['title'], type:j['type'],
    due:DateTime.parse(j['due']), amount:j['amount'] ?? '',
    person:j['person'] ?? 'Famiglia', status:j['status'] ?? 'Da fare',
    filePath:j['filePath'] ?? '', notes:j['notes'] ?? '');
  Entry copy({String? status}) => Entry(id:id,title:title,type:type,due:due,
    amount:amount,person:person,status:status ?? this.status,filePath:filePath,notes:notes);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  List<Entry> entries = [];
  final picker = ImagePicker();
  final df = DateFormat('dd/MM/yyyy');

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('entries') ?? '[]';
    try { entries = (jsonDecode(raw) as List).map((e)=>Entry.fromJson(e)).toList(); }
    catch (_) { entries = []; }
    if (mounted) setState(() {});
  }
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('entries', jsonEncode(entries.map((e)=>e.toJson()).toList()));
  }
  Future<void> _notify(Entry e) async {
    final when = DateTime(e.due.year,e.due.month,e.due.day,9);
    if (when.isBefore(DateTime.now())) return;
    const details = NotificationDetails(android: AndroidNotificationDetails(
      'vita_scadenze','Scadenze',channelDescription:'Promemoria di VitaInOrdine',
      importance: Importance.high, priority: Priority.high));
    await notifications.schedule(e.id.hashCode, 'Scadenza: ${e.title}',
      'Data: ${df.format(e.due)}', when, details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle);
  }
  List<Entry> get sorted => [...entries]..sort((a,b)=>a.due.compareTo(b.due));
  int get urgent => entries.where((e)=>e.status!='Pagata' && e.due.difference(DateTime.now()).inDays<=3).length;

  Future<void> _addEntry() async {
    final title = TextEditingController();
    final amount = TextEditingController();
    final notes = TextEditingController();
    String type = 'Scadenza';
    String person = 'Famiglia';
    DateTime due = DateTime.now().add(const Duration(days:7));
    String path = '';
    final result = await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(
      builder:(ctx, refresh)=>AlertDialog(
        title: const Text('Nuovo elemento'),
        content: SingleChildScrollView(child: Column(mainAxisSize:MainAxisSize.min,children:[
          TextField(controller:title,decoration:const InputDecoration(labelText:'Titolo *')),
          const SizedBox(height:8),
          DropdownButtonFormField<String>(value:type,decoration:const InputDecoration(labelText:'Categoria'),
            items:['Scadenza','Bol­letta','Documento','Appuntamento','Attività','Spesa']
              .map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v)=>refresh(()=>type=v!)),
          TextField(controller:amount,decoration:const InputDecoration(labelText:'Importo (facoltativo)'),
            keyboardType:TextInputType.number),
          DropdownButtonFormField<String>(value:person,decoration:const InputDecoration(labelText:'Assegnato a'),
            items:['Famiglia','Io','Partner','Figlio/a'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v)=>refresh(()=>person=v!)),
          ListTile(contentPadding:EdgeInsets.zero,title:const Text('Data'),
            subtitle:Text(df.format(due)),trailing:const Icon(Icons.calendar_month),
            onTap:() async { final d=await showDatePicker(context:ctx,initialDate:due,
              firstDate:DateTime(2020),lastDate:DateTime(2100)); if(d!=null) refresh(()=>due=d); }),
          TextField(controller:notes,decoration:const InputDecoration(labelText:'Note')),
          if(path.isNotEmpty) Text(path, maxLines:1, overflow:TextOverflow.ellipsis),
          Align(alignment:Alignment.centerLeft,child:TextButton.icon(
            onPressed:() async { final f=await FilePicker.platform.pickFiles();
              if(f!=null && f.files.single.path!=null) refresh(()=>path=f.files.single.path!); },
            icon:const Icon(Icons.attach_file),label:const Text('Allega PDF o documento'))),
        ])),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Annulla')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Salva'))],
      )));
    if(result==true && title.text.trim().isNotEmpty) {
      final e=Entry(id:DateTime.now().microsecondsSinceEpoch.toString(),
        title:title.text.trim(),type:type,due:due,amount:amount.text.trim(),
        person:person,filePath:path,notes:notes.text.trim());
      setState(()=>entries.add(e)); await _save(); await _notify(e);
    }
  }

  Future<void> _scanPhoto() async {
    final x=await picker.pickImage(source:ImageSource.camera,imageQuality:85);
    if(x==null) return;
    String recognized='';
    try {
      final input=InputImage.fromFilePath(x.path);
      final text=await TextRecognizer(script:TextRecognitionScript.latin).processImage(input);
      recognized=text.text;
    } catch (_) {}
    if(!mounted) return;
    final controller=TextEditingController(text:recognized);
    await showDialog(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Testo riconosciuto'),
      content:SizedBox(width:400,child:SingleChildScrollView(child:TextField(
        controller:controller,maxLines:10,decoration:const InputDecoration(
          hintText:'Il testo estratto apparirà qui. Controlla sempre i dati.')))),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Chiudi')),
        FilledButton(onPressed:() { Navigator.pop(ctx); _addFromScan(controller.text); },
          child:const Text('Crea scadenza'))]));
  }
  Future<void> _addFromScan(String text) async {
    final c=TextEditingController(text:text);
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Salva documento / promemoria'),
      content:TextField(controller:c,maxLines:5,decoration:const InputDecoration(
        labelText:'Testo e dettagli (da verificare)')),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Annulla')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Salva'))]));
    if(ok==true) {
      final e=Entry(id:DateTime.now().microsecondsSinceEpoch.toString(),
        title:'Documento da controllare',type:'Documento',
        due:DateTime.now().add(const Duration(days:30)),notes:c.text);
      setState(()=>entries.add(e)); await _save();
    }
  }

  Future<void> _toggle(Entry e) async {
    final next=e.status=='Pagata'?'Da fare':'Pagata';
    setState(()=>entries[entries.indexWhere((x)=>x.id==e.id)]=e.copy(status:next));
    await _save();
  }
  Future<void> _delete(Entry e) async {
    setState(()=>entries.removeWhere((x)=>x.id==e.id)); await _save();
    await notifications.cancel(e.id.hashCode);
  }
  Color _urgency(Entry e) {
    final days=e.due.difference(DateTime.now()).inDays;
    if(days<0) return Colors.red;
    if(days<=3) return Colors.orange;
    return Colors.green;
  }
  IconData _icon(String t) => switch(t) {
    'Bol­letta'=>Icons.receipt_long, 'Documento'=>Icons.folder,
    'Appuntamento'=>Icons.event, 'Attività'=>Icons.check_circle_outline,
    'Spesa'=>Icons.shopping_cart, _=>Icons.alarm};
  Widget _entryCard(Entry e) => Card(child:ListTile(
    leading:CircleAvatar(backgroundColor:_urgency(e).withOpacity(.12),
      child:Icon(_icon(e.type),color:_urgency(e))),
    title:Text(e.title,style:TextStyle(decoration:e.status=='Pagata'?TextDecoration.lineThrough:null,
      fontWeight:FontWeight.w600)),
    subtitle:Text('${e.type} • ${df.format(e.due)} • ${e.person}'
      '${e.amount.isNotEmpty?' • € ${e.amount}':''}'),
    trailing:PopupMenuButton<String>(onSelected:(v){if(v=='toggle') _toggle(e); if(v=='delete') _delete(e);},
      itemBuilder:(_)=>[PopupMenuItem(value:'toggle',child:Text(e.status=='Pagata'?'Segna da fare':'Segna completata')),
        const PopupMenuItem(value:'delete',child:Text('Elimina'))])));
  Widget _dashboard() {
    final upcoming=sorted.where((e)=>e.status!='Pagata').take(5).toList();
    return ListView(padding:const EdgeInsets.all(18),children:[
      const SizedBox(height:8),
      const Text('La tua famiglia,',style:TextStyle(fontSize:16,color:Colors.black54)),
      const Text('tutto sotto controllo.',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),
      const SizedBox(height:18),
      Row(children:[
        Expanded(child:_metric('Da gestire','${entries.where((e)=>e.status!="Pagata").length}',Icons.pending_actions)),
        const SizedBox(width:10),
        Expanded(child:_metric('Urgenti','$urgent',Icons.warning_amber_rounded)),
      ]),
      const SizedBox(height:20),
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        const Text('Prossime scadenze',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        TextButton(onPressed:()=>setState(()=>tab=1),child:const Text('Vedi tutte'))]),
      if(upcoming.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(20),
        child:Text('Nessuna scadenza. Aggiungi il primo impegno!'))),
      ...upcoming.map(_entryCard),
      const SizedBox(height:12),
      const Text('Azioni rapide',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      Row(children:[
        Expanded(child:_quick('Aggiungi',Icons.add,_addEntry)),
        const SizedBox(width:10),
        Expanded(child:_quick('Fotografa',Icons.camera_alt,_scanPhoto)),
      ]),
    ]);
  }
  Widget _metric(String label,String value,IconData icon)=>Card(child:Padding(
    padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(icon,color:Theme.of(context).colorScheme.primary),
      const SizedBox(height:12),Text(value,style:const TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
      Text(label,style:const TextStyle(color:Colors.black54))])));
  Widget _quick(String label,IconData icon,VoidCallback action)=>FilledButton.tonal(
    onPressed:action,style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:18)),
    child:Column(children:[Icon(icon),const SizedBox(height:6),Text(label)]));
  Widget _list(String type) {
    final list=sorted.where((e)=>type=='Tutti'||e.type==type).toList();
    return ListView(padding:const EdgeInsets.all(16),children:[
      Text(type=='Tutti'?'Tutti gli elementi':type,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      if(list.isEmpty) const Text('Ancora nessun elemento. Usa il pulsante + per aggiungerne uno.'),
      ...list.map(_entryCard)]);
  }
  @override Widget build(BuildContext context) {
    final pages=[_dashboard(),_list('Tutti'),_list('Documento'),_list('Attività')];
    return Scaffold(
      appBar:AppBar(title:const Text('VitaInOrdine',style:TextStyle(fontWeight:FontWeight.bold)),
        actions:[IconButton(onPressed:_scanPhoto,tooltip:'Fotografa documento',icon:const Icon(Icons.document_scanner))]),
      body:SafeArea(child:pages[tab]),
      floatingActionButton:FloatingActionButton(onPressed:_addEntry,child:const Icon(Icons.add)),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations:const [
          NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
          NavigationDestination(icon:Icon(Icons.calendar_month_outlined),selectedIcon:Icon(Icons.calendar_month),label:'Scadenze'),
          NavigationDestination(icon:Icon(Icons.folder_outlined),selectedIcon:Icon(Icons.folder),label:'Documenti'),
          NavigationDestination(icon:Icon(Icons.checklist),label:'Attività'),
        ]),
    );
  }
}
