# VitaInOrdine – MVP Android/iOS (Flutter)

## Stato
Prima base MVP offline-first. Include dashboard, elementi per scadenze/documenti/attività,
salvataggio locale, allegato file, acquisizione foto con OCR locale e notifiche locali.

## Limiti dichiarati
- Non include ancora account, backup cloud o sincronizzazione tra telefoni.
- OCR estrae testo; non interpreta in modo affidabile importi/date: verifica sempre i dati.
- L'app non effettua pagamenti.
- Le notifiche richiedono i permessi del sistema operativo.
- L'allegato viene referenziato dal percorso locale: backup/esportazione e gestione robusta
  dei file sono da completare prima di uso con documenti importanti.

## Build Android
Aprire il progetto con Flutter 3.24.5 o successivo compatibile:
`flutter pub get`, `flutter analyze`, `flutter test`, `flutter build apk --release`.

Il workflow GitHub Actions in `.github/workflows/android-apk.yml` esegue questi passaggi
e pubblica l'APK come artifact al termine.

## iOS
Il progetto è Flutter e può essere esteso a iOS. Per compilare e firmare la versione iOS
serve un Mac con Xcode e un account Apple Developer per la distribuzione App Store.
